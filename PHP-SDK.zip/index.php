<?php
require_once(__DIR__.DIRECTORY_SEPARATOR.'src/Collins.php');
use CollinsAPI\Collins;

$result = Collins::getProductSearch(12345);
print_r($result);