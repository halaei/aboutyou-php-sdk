<?php
require('src/Collins.php');
use CollinsAPI\Collins;

$result = Collins::getProductSearch(12345);

$farbcodes = Collins::getFacets(\CollinsAPI\Constants::FACET_COLOR);
print_r($farbcodes->facet);