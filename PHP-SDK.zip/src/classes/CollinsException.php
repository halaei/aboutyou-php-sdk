<?php
namespace CollinsAPI;

/**
 * Thrown if an API call returns an exception.
 *
 * @author Antevorte GmbH
 */
class CollinsException extends \Exception
{
	
}