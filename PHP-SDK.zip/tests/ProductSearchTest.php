<?php
class ProductSearchTest extends PHPUnit_Framework_TestCase
{
	public function testProductSearch()
	{
		
	}
}